<?php get_header(); while(have_posts()):the_post();?>
<article class="trail">
<?php the_post_thumbnail();?>
<h1><?php the_title();?></h1>
<div class="facts">
<span>Difficulty: <?php echo get_post_meta(get_the_ID(),'difficulty',true);?></span>
<span>Distance: <?php echo get_post_meta(get_the_ID(),'distance',true);?></span>
</div>
<?php the_content();?>
</article>
<?php endwhile; get_footer();?>
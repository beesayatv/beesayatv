<?php get_header(); ?>
<section class="hero"><h1>Find Your Next Cebu Trail</h1><p>Documented hikes and trail guides.</p></section>
<section class="grid">
<?php $q=new WP_Query(['post_type'=>'trail']); while($q->have_posts()):$q->the_post(); ?>
<a class="card" href="<?php the_permalink();?>"><?php the_post_thumbnail();?><h2><?php the_title();?></h2></a>
<?php endwhile;?>
</section>
<?php get_footer();?>
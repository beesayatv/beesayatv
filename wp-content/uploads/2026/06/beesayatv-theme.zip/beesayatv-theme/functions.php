<?php
add_theme_support('post-thumbnails');
function beesaya_assets(){wp_enqueue_style('main',get_template_directory_uri().'/assets/css/main.css');}
add_action('wp_enqueue_scripts','beesaya_assets');
function beesaya_trails(){
 register_post_type('trail',array('label'=>'Trails','public'=>true,'has_archive'=>true,'menu_icon'=>'dashicons-location-alt','supports'=>array('title','editor','thumbnail','custom-fields')));
}
add_action('init','beesaya_trails');
?>